<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Assuming your React Native app sends recipe data and user ID in JSON format
    $data = json_decode(file_get_contents('php://input'), true);

    $name = $data['name'];
    $ingredients = $data['ingredients'];
    $user_id = $data['user_id']; // Assuming user ID is sent from the client

    // Prepare and bind the INSERT statement
    $stmt = $conn->prepare("INSERT INTO recipes (name, ingredients, user_id) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $ingredients, $user_id);

    // Execute the statement
    if ($stmt->execute() === TRUE) {
        $response = array("success" => true);
        echo json_encode($response);
    } else {
        $response = array("success" => false, "error" => $conn->error);
        echo json_encode($response);
    }

    // Close the connection
    $stmt->close();
    $conn->close();
}
?>