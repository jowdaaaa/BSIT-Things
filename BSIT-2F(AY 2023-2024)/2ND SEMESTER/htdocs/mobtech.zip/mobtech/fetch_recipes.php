<?php

include 'db.php';

// Fetch recipes from database
$sql = "SELECT * FROM recipes"; // Change "recipes" to your actual table name
$result = $conn->query($sql);

$recipes = array();

if ($result->num_rows > 0) {
  // Output data of each row
  while($row = $result->fetch_assoc()) {
    // Add each recipe to the recipes array
    $recipes[] = $row;
  }
} else {
  echo "0 results";
}

// Close connection
$conn->close();

// Output recipes as JSON
header('Content-Type: application/json');
echo json_encode(array('recipes' => $recipes));
?>