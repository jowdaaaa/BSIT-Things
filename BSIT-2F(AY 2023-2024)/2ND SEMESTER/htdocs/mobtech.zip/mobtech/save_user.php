<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = json_decode(file_get_contents('php://input'), true);
    
    $name = $user['name'];
    $email = $user['email'];
    $picture = $user['picture'];
    
    $sql = "INSERT INTO users (name, email, picture) VALUES ('$name', '$email', '$picture')";
    
    if ($conn->query($sql) === TRUE) {
        echo json_encode(["success" => true]);
    } else {
        echo json_encode(["success" => false, "error" => $conn->error]);
    }
    
    $conn->close();
}
?>