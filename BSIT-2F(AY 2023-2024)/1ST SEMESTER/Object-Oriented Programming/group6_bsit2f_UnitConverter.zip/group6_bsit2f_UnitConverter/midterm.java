import java.util.Scanner;

public class midterm {
	public static void main (String[] args) {

        Scanner s = new Scanner(System.in);
		Area area = new Area();
		Length length = new Length();
		Temperature temp = new Temperature();
		Volume volume = new Volume();
		Mass mass = new Mass();
		boolean l=true;
		
		while (l){
			System.out.println("+=================== WELCOME TO UNIT CONVERTER ====================");
			System.out.println("|| Select a Unit :                                               ||");
			System.out.println("||                 [1] Area                                      ||");
			System.out.println("||                 [2] Length                                    ||");
			System.out.println("||                 [3] Temperature                               ||");
			System.out.println("||                 [4] Volume                                    ||");
			System.out.println("||                 [5] Mass                                      ||");
			System.out.println("||                 [0] Exit                                      ||");
			System.out.println("===================================================================");

			System.out.print("Input your choice [0-5]: ");
			int choice1 = s.nextInt();

			switch (choice1) {
				case 1 :
					area.a();
					break;
					
				case 2 :
					length.l();
					break;
					
				case 3 :
					temp.t();
					break;
					
				case 4 :
					volume.v();
					break;
					
				case 5 :
					mass.m();
					break;
					
				case 0 :
					l=false;
					break;

				default: 
					System.out.println ("INVALID INPUT!");
					break;
			}
		}
		s.close();
		System.out.println("\n===================================================================");
		System.out.println("======================= T H A N K    Y O U  =======================");
		System.out.println("===================================================================");
    }
}

class Area {
    public void a() {
		Scanner s = new Scanner(System.in);
		boolean t=true;
		
		while(t){
			System.out.println("-----------------------------------");
			System.out.println("Select Area Unit:");
			System.out.println("   [1] Hectares(ha)");
			System.out.println("   [2] Square Centimeters(cm²)");
			System.out.println("   [3] Square Feet(ft²)");
			System.out.println("   [4] Square Inches(in²)");
			System.out.println("   [5] Square Meters(m²)");
			System.out.println("   [0] Exit");
			System.out.println("-----------------------------------");
			
			System.out.print("Input your choice [0-5]: ");
			int choice2 = s.nextInt();
			
			switch (choice2) {
				case 1: 
					System.out.print("Input value of Hectares(ha): ");
					double hec = s.nextDouble();
					
					System.out.println("-----------------------------------");
					System.out.println("Select Area Unit:");
					System.out.println("   [1] Square Centimeters(cm²)");
					System.out.println("   [2] Square Feet(ft²)");
					System.out.println("   [3] Square Inches(in²)");
					System.out.println("   [4] Square Meters(m²)");
					System.out.println("-----------------------------------");
					
					boolean h=true;
					while (h) {
						System.out.print("Convert to: ");
						int unit = s.nextInt();
						
						if (unit == 1){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (hec * 10000000) + "cm²" );
							System.out.println("===================================\n");
							h=false;
							t=false;
						} else if (unit == 2){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (hec * 107639.104) + "ft²" );
							System.out.println("===================================\n");
							h=false;
							t=false;
						} else if (unit == 3){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (hec * 15500031) + "in²" );
							System.out.println("===================================\n");
							h=false;
							t=false;
						} else if (unit == 4){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (hec * 10000) + "m²" );
							System.out.println("===================================\n");
							h=false;
							t=false;
						} else {
							System.out.println("INVALID INPUT!");
						}
					}
						
					break;
					
				case 2: 
				
					System.out.print("Input value of Square Centimeters(cm²): ");
					double cen = s.nextDouble();
					
					System.out.println("-----------------------------------");
					System.out.println("Select Area Unit:");
					System.out.println("   [1] Hectares(ha)");
					System.out.println("   [2] Square Feet(ft²)");
					System.out.println("   [3] Square Inches(in²)");
					System.out.println("   [4] Square Meters(m²)");
					System.out.println("-----------------------------------");
					
					boolean c=true;
					while (c) {
						System.out.print("Convert to: ");
						int unit = s.nextInt();
						
						if (unit == 1){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (cen / 10000) + "ha" );
							System.out.println("===================================\n");
							c=false;
							t=false;
						} else if (unit == 2){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (cen * 0.00107639) + "ft²" );
							System.out.println("===================================\n");
							c=false;
							t=false;
						} else if (unit == 3){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (cen * 0.1550) + "in²" );
							System.out.println("===================================\n");
							c=false;
							t=false;
						} else if (unit == 4){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (cen * 0.0001) + "m²" );
							System.out.println("===================================\n");
							c=false;
							t=false;
						} else {
							System.out.println("INVALID INPUT!");
						}
					}
						
					break;
					
				case 3: 
				
					System.out.print("Input value of Square Feet(ft²): ");
					double feet = s.nextDouble();
					
					System.out.println("-----------------------------------");
					System.out.println("Select Area Unit:");
					System.out.println("   [1] Hectares(ha)");
					System.out.println("   [2] Square Centimeters(cm²)");
					System.out.println("   [3] Square Inches(in²)");
					System.out.println("   [4] Square Meters(m²)");
					System.out.println("-----------------------------------");
					
					boolean f=true;
					while (f) {
						System.out.print("Convert to: ");
						int unit = s.nextInt();
						
						if (unit == 1){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (feet / 10763.9) + "ha" );
							System.out.println("===================================\n");
							f=false;
							t=false;
						} else if (unit == 2){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (feet * 929.0304) + "cm²" );
							System.out.println("===================================\n");
							f=false;
							t=false;
						} else if (unit == 3){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (feet * 144) + "in²" );
							System.out.println("===================================\n");
							f=false;
							t=false;
						} else if (unit == 4){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (feet * 0.092903) + "m²" );
							System.out.println("===================================\n");
							f=false;
							t=false;
						} else {
							System.out.println("INVALID INPUT!");
						}
					}
						
					break;
				
				case 4: 
				
					System.out.print("Input value of Square Inches(in²): ");
					double inc = s.nextDouble();
					
					System.out.println("-----------------------------------");
					System.out.println("Select Area Unit:");
					System.out.println("   [1] Hectares(ha)");
					System.out.println("   [2] Square Centimeters(cm²)");
					System.out.println("   [3] Square Feet(ft²)");
					System.out.println("   [4] Square Meters(m²)");
					System.out.println("-----------------------------------");
					
					boolean i=true;
					while (i) {
						System.out.print("Convert to: ");
						int unit = s.nextInt();
						
						if (unit == 1){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + ((inc * 0.00064516) / 10000) + "ha" );
							System.out.println("===================================\n");
							i=false;
							t=false;
						} else if (unit == 2){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (inc * 6.4516) + "cm²" );
							System.out.println("===================================\n");
							i=false;
							t=false;
						} else if (unit == 3){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (inc * 144) + "ft²" );
							System.out.println("===================================\n");
							i=false;
							t=false;
						} else if (unit == 4){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (inc * 0.00064516) + "m²" );
							System.out.println("===================================\n");
							i=false;
							t=false;
						} else {
							System.out.println("INVALID INPUT!");
						}
					}
						
					break;
				
				case 5: 
				
					System.out.print("Input value of Square Meters(m²): ");
					double met = s.nextDouble();
					
					System.out.println("-----------------------------------");
					System.out.println("Select Area Unit:");
					System.out.println("   [1] Hectares(ha)");
					System.out.println("   [2] Square Centimeters(cm²)");
					System.out.println("   [3] Square Feet(ft²)");
					System.out.println("   [4] Square Inches(in²)");
					System.out.println("-----------------------------------");
					
					boolean m=true;
					while (m) {
						System.out.print("Convert to: ");
						int unit = s.nextInt();
						
						if (unit == 1){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (met * 10000) + "ha" );
							System.out.println("===================================\n");
							m=false;
							t=false;
						} else if (unit == 2){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (met * 10000) + "cm²" );
							System.out.println("===================================\n");
							m=false;
							t=false;
						} else if (unit == 3){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (met * 10.7639) + "ft²" );
							System.out.println("===================================\n");
							m=false;
							t=false;
						} else if (unit == 4){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (met * 1550.0031) + "in²" );
							System.out.println("===================================\n");
							m=false;
							t=false;
						} else {
							System.out.println("INVALID INPUT!");
						}
					}
						
					break;
				
				case 0: 
					t=false;
					break;
				default:
					System.out.println("INVALID INPUT!");
					break;
				
			}
		}	
		
    }
}

class Length {
    public void l() {
        Scanner s = new Scanner(System.in);
		boolean t=true;
		
		while(t){
			System.out.println("-----------------------------------");
			System.out.println("Select Length Unit:");
			System.out.println("   [1] Centimeters(cm)");
			System.out.println("   [2] Meters(m)");
			System.out.println("   [3] Kilometers(km)");
			System.out.println("   [4] Inches(in)");
			System.out.println("   [5] Feet(ft)");
			System.out.println("   [0] Exit");
			System.out.println("-----------------------------------");
			
			System.out.print("Input your choice [0-5]: ");
			int choice2 = s.nextInt();
			
			switch (choice2) {
				case 1: 
					System.out.print("Input value of Centimeters(cm): ");
					double cen = s.nextDouble();
					
					System.out.println("-----------------------------------");
					System.out.println("Select Length Unit:");
					System.out.println("   [1] Meters(m)");
					System.out.println("   [2] Kilometers(km)");
					System.out.println("   [3] Inches(in)");
					System.out.println("   [4] Feet(ft)");
					System.out.println("-----------------------------------");
					
					boolean h=true;
					while (h) {
						System.out.print("Convert to: ");
						int unit = s.nextInt();
						
						if (unit == 1){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (cen / 100) + "m" );
							System.out.println("===================================\n");
							h=false;
							t=false;
						} else if (unit == 2){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (cen / 100000 + "km") );
							System.out.println("===================================\n");
							h=false;
							t=false;
						} else if (unit == 3){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (cen * 0.393701) + "in" );
							System.out.println("===================================\n");
							h=false;
							t=false;
						} else if (unit == 4){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (cen * 0.0328084 + "ft") );
							System.out.println("===================================\n");
							h=false;
							t=false;
						} else {
							System.out.println("INVALID INPUT!");
						}
					}
						
					break;
					
				case 2: 
				
					System.out.print("Input value of Meters(m): ");
					double met = s.nextDouble();
					
					System.out.println("-----------------------------------");
					System.out.println("Select Length Unit:");
					System.out.println("   [1] Centimeters(cm)");
					System.out.println("   [2] Kilometers(km)");
					System.out.println("   [3] Inches(in)");
					System.out.println("   [4] Feet(ft)");
					System.out.println("-----------------------------------");
					
					boolean c=true;
					while (c) {
						System.out.print("Convert to: ");
						int unit = s.nextInt();
						
						if (unit == 1){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (met * 100 + "cm") );
							System.out.println("===================================\n");
							c=false;
							t=false;
						} else if (unit == 2){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (met / 1000) + "km" );
							System.out.println("===================================\n");
							c=false;
							t=false;
						} else if (unit == 3){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (met * 39.3701) + "in" );
							System.out.println("===================================\n");
							c=false;
							t=false;
						} else if (unit == 4){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (met * 3.28084) + "ft" );
							System.out.println("===================================\n");
							c=false;
							t=false;
						} else {
							System.out.println("INVALID INPUT!");
						}
					}
						
					break;
					
				case 3: 
				
					System.out.print("Input value of Kilometers(km): ");
					double kil = s.nextDouble();
					
					System.out.println("-----------------------------------");
					System.out.println("Select Length Unit:");
					System.out.println("   [1] Centimeters(cm)");
					System.out.println("   [2] Meters(m)");
					System.out.println("   [3] Inches(in)");
					System.out.println("   [4] Feet(ft)");
					System.out.println("-----------------------------------");
					
					boolean f=true;
					while (f) {
						System.out.print("Convert to: ");
						int unit = s.nextInt();
						
						if (unit == 1){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (kil * 100000) + "cm" );
							System.out.println("===================================\n");
							f=false;
							t=false;
						} else if (unit == 2){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (kil * 1000) + "m" );
							System.out.println("===================================\n");
							f=false;
							t=false;
						} else if (unit == 3){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (kil * 39370.1) + "in" );
							System.out.println("===================================\n");
							f=false;
							t=false;
						} else if (unit == 4){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (kil * 3280.84) + "ft" );
							System.out.println("===================================\n");
							f=false;
							t=false;
						} else {
							System.out.println("INVALID INPUT!");
						}
					}
						
					break;
				
				case 4: 
				
					System.out.print("Input value of Inches(in): ");
					double inc = s.nextDouble();
					
					System.out.println("-----------------------------------");
					System.out.println("Select Length Unit:");
					System.out.println("   [1] Centimeters(cm)");
					System.out.println("   [2] Meters(m)");
					System.out.println("   [3] Kilometers(km)");
					System.out.println("   [4] Feet(ft)");
					System.out.println("-----------------------------------");
					
					boolean i=true;
					while (i) {
						System.out.print("Convert to: ");
						int unit = s.nextInt();
						
						if (unit == 1){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (inc * 2.54) + "cm" );
							System.out.println("===================================\n");
							i=false;
							t=false;
						} else if (unit == 2){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (inc * 0.0254) + "m" );
							System.out.println("===================================\n");
							i=false;
							t=false;
						} else if (unit == 3){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (inc * 0.0000254) + "km" );
							System.out.println("===================================\n");
							i=false;
							t=false;
						} else if (unit == 4){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (inc / 12) + "ft" );
							System.out.println("===================================\n");
							i=false;
							t=false;
						} else {
							System.out.println("INVALID INPUT!");
						}
					}
						
					break;
				
				case 5: 
				
					System.out.print("Input value of Feet(ft): ");
					double feet = s.nextDouble();
					
					System.out.println("-----------------------------------");
					System.out.println("Select Length Unit:");
					System.out.println("   [1] Centimeters(cm)");
					System.out.println("   [2] Meters(m)");
					System.out.println("   [3] Kilometers(km)");
					System.out.println("   [4] Inches(in)");
					System.out.println("-----------------------------------");
					
					boolean m=true;
					while (m) {
						System.out.print("Convert to: ");
						int unit = s.nextInt();
						
						if (unit == 1){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (feet * 30.48) + "cm" );
							System.out.println("===================================\n");
							m=false;
							t=false;
						} else if (unit == 2){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (feet * 0.3048) + "m" );
							System.out.println("===================================\n");
							m=false;
							t=false;
						} else if (unit == 3){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (feet * 0.003048) + "km" );
							System.out.println("===================================\n");
							m=false;
							t=false;
						} else if (unit == 4){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (feet * 12) + "in" );
							System.out.println("===================================\n");
							m=false;
							t=false;
						} else {
							System.out.println("INVALID INPUT!");
						}
					}
						
					break;
				
				case 0: 
					t=false;
					break;
				default:
					System.out.println("INVALID INPUT!");
					break;
			}
		}
		
    }
}

class Temperature {
	public void t() {
        Scanner s = new Scanner(System.in);
		boolean t=true;
		
		while(t){
			System.out.println("-----------------------------------");
			System.out.println("Select area unit:");
			System.out.println("   [1] Celcius(°C)");
			System.out.println("   [2] Fahrenheit(°F)");
			System.out.println("   [3] Kelvin(K)");
			System.out.println("   [0] Exit");
			System.out.println("-----------------------------------");
			
			System.out.print("Input your choice [0-3]: ");
			int choice2 = s.nextInt();
			
			switch (choice2) {
				case 1: 
					System.out.print("Input value of Celcius(°C): ");
					double cel = s.nextDouble();
					
					System.out.println("-----------------------------------");
					System.out.println("Select Temperature Unit:");
					System.out.println("   [1] Fahrenheit(°F)");
					System.out.println("   [2] Kelvin(K)");
					System.out.println("-----------------------------------");
					
					boolean h=true;
					while (h) {
						System.out.print("Convert to: ");
						int unit = s.nextInt();
						
						if (unit == 1){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (cel * 9 / 5 + 32) + "°F");
							System.out.println("===================================\n");
							h=false;
							t=false;
						} else if (unit == 2){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (cel + 273.15) + "K");
							System.out.println("===================================\n");
							h=false;
							t=false;
						} else {
							System.out.println("INVALID INPUT!");
						}
					}
						
					break;
					
				case 2: 
				
					System.out.print("Input value of Fahrenheit(°F): ");
					double fah = s.nextDouble();
					
					System.out.println("-----------------------------------");
					System.out.println("Select Temperature Unit:");
					System.out.println("   [1] Celcius(°C)");
					System.out.println("   [2] Kelvin(K)");
					System.out.println("-----------------------------------");
					
					boolean c=true;
					while (c) {
						System.out.print("Convert to: ");
						int unit = s.nextInt();
						
						if (unit == 1){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + ((fah - 32) * 5/9)  + "°C" );
							System.out.println("===================================\n");
							c=false;
							t=false;
						} else if (unit == 2){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + ((fah - 32) * 5/9 + 273.15) + "K" );
							System.out.println("===================================\n");
							c=false;
							t=false;
						} else {
							System.out.println("INVALID INPUT!");
						}
					}
						
					break;
					
				case 3: 
				
					System.out.print("Input value of Kelvin(K): ");
					double kil = s.nextDouble();
					
					System.out.println("-----------------------------------");
					System.out.println("Select Temperature Unit:");
					System.out.println("   [1] Celcius(°C)");
					System.out.println("   [2] Fahrenheit(°F)");
					System.out.println("-----------------------------------");
					
					boolean f=true;
					while (f) {
						System.out.print("Convert to: ");
						int unit = s.nextInt();
						
						if (unit == 1){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (kil - 273.15) + "°C" );
							System.out.println("===================================\n");
							f=false;
							t=false;
						} else if (unit == 2){
							System.out.println("===================================");
							System.out.println("  ANSWER : " + ((kil - 273.15) * 9/5 + 32) + "°F" );
							System.out.println("===================================\n");
							f=false;
							t=false;
						} else {
							System.out.println("INVALID INPUT!");
						}
					}
						
					break;
				
				case 0: 
					t=false;
					break;

				default:
					System.out.println("INVALID INPUT!");
					break;
			}
		}

	}
}

class Volume {
	public void v() {
        Scanner s = new Scanner(System.in);
        boolean t = true;

        while (t) {
            System.out.println("-----------------------------------");
            System.out.println("Select Volume Unit:");
            System.out.println("   [1] Liters(L)");
            System.out.println("   [2] Milliliters(mL)");
            System.out.println("   [3] Cubic Centimeters(cm³)");
            System.out.println("   [4] Cubic Meters(m³)");
            System.out.println("   [5] Cubic Inches(in³)");
            System.out.println("   [0] Exit");
            System.out.println("-----------------------------------");

            System.out.print("Input your choice [0-5]: ");
            int choice2 = s.nextInt();

            switch (choice2) {
                case 1:
                    System.out.print("Input value of Liters(L): ");
                    double liters = s.nextDouble();

                    System.out.println("-----------------------------------");
                    System.out.println("Select Volume Unit:");
                    System.out.println("   [1] Milliliters(mL)");
                    System.out.println("   [2] Cubic Centimeters(cm³)");
                    System.out.println("   [3] Cubic Meters(m³)");
                    System.out.println("   [4] Cubic Inches(in³)");
                    System.out.println("-----------------------------------");

                    boolean h = true;
                    while (h) {
                        System.out.print("Convert to: ");
                        int unit = s.nextInt();

                        if (unit == 1) {
                            System.out.println("===================================");
                            System.out.println("  ANSWER : " + (liters * 1000) + "mL");
                            System.out.println("===================================\n");
                            h = false;
                            t = false;
                        } else if (unit == 2) {
                            System.out.println("===================================");
                            System.out.println("  ANSWER : " + (liters * 1000) + "cm³");
                            System.out.println("===================================\n");
                            h = false;
                            t = false;
                        } else if (unit == 3) {
                            System.out.println("===================================");
                            System.out.println("  ANSWER : " + (liters * 0.001) + "m³");
                            System.out.println("===================================\n");
                            h = false;
                            t = false;
                        } else if (unit == 4) {
                            System.out.println("===================================");
                            System.out.println("  ANSWER : " + (liters * 61.0237) + "in³");
                            System.out.println("===================================\n");
                            h = false;
                            t = false;
                        } else {
                            System.out.println("INVALID INPUT!");
                        }
                    }

                    break;

                case 2:

                    System.out.print("Input value of Milliliters(mL): ");
                    double milliliters = s.nextDouble();

                    System.out.println("-----------------------------------");
                    System.out.println("Select Volume Unit:");
                    System.out.println("   [1] Liters(L)");
                    System.out.println("   [2] Cubic Centimeters(cm³)");
                    System.out.println("   [3] Cubic Meters(m³)");
                    System.out.println("   [4] Cubic Inches(in³)");
                    System.out.println("-----------------------------------");

                    boolean c = true;
                    while (c) {
                        System.out.print("Convert to: ");
                        int unit = s.nextInt();

                        if (unit == 1) {
                            System.out.println("===================================");
                            System.out.println("  ANSWER : " + (milliliters * 0.001) + "L");
                            System.out.println("===================================\n");
                            c = false;
                            t = false;
                        } else if (unit == 2) {
                            System.out.println("===================================");
                            System.out.println("  ANSWER : " + (milliliters * 1) + "cm³");
                            System.out.println("===================================\n");
                            c = false;
                            t = false;
                        } else if (unit == 3) {
                            System.out.println("===================================");
                            System.out.println("  ANSWER : " + (milliliters * 0.000001) + "m³");
                            System.out.println("===================================\n");
                            c = false;
                            t = false;
                        } else if (unit == 4) {
                            System.out.println("===================================");
                            System.out.println("  ANSWER : " + (milliliters * 0.0610237) + "in³");
                            System.out.println("===================================\n");
                            c = false;
                            t = false;
                        } else {
                            System.out.println("INVALID INPUT!");
                        }
                    }

                    break;

                case 3:

                    System.out.print("Input value of Cubic Centimeters(cm³): ");
                    double cubicCentimeters = s.nextDouble();

                    System.out.println("-----------------------------------");
                    System.out.println("Select Volume Unit:");
                    System.out.println("   [1] Liters(L)");
                    System.out.println("   [2] Milliliters(mL)");
                    System.out.println("   [3] Cubic Meters(m³)");
                    System.out.println("   [4] Cubic Inches(in³)");
                    System.out.println("-----------------------------------");

                    boolean f = true;
                    while (f) {
                        System.out.print("Convert to: ");
                        int unit = s.nextInt();

                        if (unit == 1) {
                            System.out.println("===================================");
                            System.out.println("  ANSWER : " + (cubicCentimeters * 0.001) + "L");
                            System.out.println("===================================\n");
                            f = false;
                            t = false;
                        } else if (unit == 2) {
                            System.out.println("===================================");
                            System.out.println("  ANSWER : " + (cubicCentimeters * 1) + "mL");
                            System.out.println("===================================\n");
                            f = false;
                            t = false;
                        } else if (unit == 3) {
                            System.out.println("===================================");
                            System.out.println("  ANSWER : " + (cubicCentimeters * 0.000001) + "m³");
                            System.out.println("===================================\n");
                            f = false;
                            t = false;
                        } else if (unit == 4) {
                            System.out.println("===================================");
                            System.out.println("  ANSWER : " + (cubicCentimeters * 0.0610237) + "in³");
                            System.out.println("===================================\n");
                            f = false;
                            t = false;
                        } else {
                            System.out.println("INVALID INPUT!");
                        }
                    }

                    break;

                case 4:

                    System.out.print("Input value of Cubic Meters(m³): ");
                    double cubicMeters = s.nextDouble();

                    System.out.println("-----------------------------------");
                    System.out.println("Select Volume Unit:");
                    System.out.println("   [1] Liters(L)");
                    System.out.println("   [2] Milliliters(mL)");
                    System.out.println("   [3] Cubic Centimeters(cm³)");
                    System.out.println("   [4] Cubic Inches(in³)");
                    System.out.println("-----------------------------------");

                    boolean i = true;
                    while (i) {
                        System.out.print("Convert to: ");
                        int unit = s.nextInt();

                        if (unit == 1) {
                            System.out.println("===================================");
                            System.out.println("  ANSWER : " + (cubicMeters * 1000) + "L");
                            System.out.println("===================================\n");
                            i = false;
                            t = false;
                        } else if (unit == 2) {
                            System.out.println("===================================");
                            System.out.println("  ANSWER : " + (cubicMeters * 1000000) + "mL");
                            System.out.println("===================================\n");
                            i = false;
                            t = false;
                        } else if (unit == 3) {
                            System.out.println("===================================");
                            System.out.println("  ANSWER : " + (cubicMeters * 1000000) + "cm³");
                            System.out.println("===================================\n");
                            i = false;
                            t = false;
                        } else if (unit == 4) {
                            System.out.println("===================================");
                            System.out.println("  ANSWER : " + (cubicMeters * 61023.7) + "in³");
                            System.out.println("===================================\n");
                            i = false;
                            t = false;
                        } else {
                            System.out.println("INVALID INPUT!");
                        }
                    }

                    break;

                case 5:

                    System.out.print("Input value of Cubic Inches(in³): ");
                    double cubicInches = s.nextDouble();

                    System.out.println("-----------------------------------");
                    System.out.println("Select Volume Unit:");
                    System.out.println("   [1] Liters(L)");
                    System.out.println("   [2] Milliliters(mL)");
                    System.out.println("   [3] Cubic Centimeters(cm³)");
                    System.out.println("   [4] Cubic Meters(m³)");
                    System.out.println("-----------------------------------");

                    boolean m = true;
                    while (m) {
                        System.out.print("Convert to: ");
                        int unit = s.nextInt();

                        if (unit == 1) {
                            System.out.println("===================================");
                            System.out.println("  ANSWER : " + ((cubicInches * 0.0163871) / 1000) + "L");
                            System.out.println("===================================\n");
                            m = false;
                            t = false;
                        } else if (unit == 2) {
                            System.out.println("===================================");
                            System.out.println("  ANSWER : " + (cubicInches * 16.3871) + "mL");
                            System.out.println("===================================\n");
                            m = false;
                            t = false;
                        } else if (unit == 3) {
                            System.out.println("===================================");
                            System.out.println("  ANSWER : " + (cubicInches * 16.3871) + "cm³");
                            System.out.println("===================================\n");
                            m = false;
                            t = false;
                        } else if (unit == 4) {
                            System.out.println("===================================");
                            System.out.println("  ANSWER : " + (cubicInches * 0.0000163871) + "m³");
                            System.out.println("===================================\n");
                            m = false;
                            t = false;
                        } else {
                            System.out.println("INVALID INPUT!");
                        }
                    }

                    break;

                case 0:
                    t = false;
                    break;
                default:
                    System.out.println("INVALID INPUT!");
                    break;
            }
        }
	}
}

class Mass {
	public void m() {
		Scanner s = new Scanner(System.in);
		boolean t = true;

		while (t) {
			System.out.println("-----------------------------------");
			System.out.println("Select Mass Unit:");
			System.out.println("   [1] Tons(t)");
			System.out.println("   [2] Pounds(lb)");
			System.out.println("   [3] Ounces(oz)");
			System.out.println("   [4] Kilograms(kg)");
			System.out.println("   [5] Grams(g)");
			System.out.println("   [0] Exit");
			System.out.println("-----------------------------------");

			System.out.print("Input your choice [0-5]: ");
			int choice2 = s.nextInt();

			switch (choice2) {
				case 1:
					System.out.print("Input value of Tons (t): ");
					double tons = s.nextDouble();

					System.out.println("-----------------------------------");
					System.out.println("Select Mass Unit:");
					System.out.println("   [1] Pounds(lb)");
					System.out.println("   [2] Ounces(oz)");
					System.out.println("   [3] Kilograms(kg)");
					System.out.println("   [4] Grams(g)");
					System.out.println("-----------------------------------");

					boolean h = true;
					while (h) {
						System.out.print("Convert to: ");
						int unit = s.nextInt();

						if (unit == 1) {
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (tons * 2204.62) + "lb");
							System.out.println("===================================\n");
							h = false;
							t = false;
						} else if (unit == 2) {
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (tons * 35274) + "oz");
							System.out.println("===================================\n");
							h = false;
							t = false;
						} else if (unit == 3) {
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (tons * 1000) + "kg");
							System.out.println("===================================\n");
							h = false;
							t = false;
						} else if (unit == 4) {
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (tons * 1000000) + "g");
							System.out.println("===================================\n");
							h = false;
							t = false;
						} else {
							System.out.println("INVALID INPUT!");
						}
					}

					break;

				case 2:

					System.out.print("Input value of Pounds(lb): ");
					double pounds = s.nextDouble();

					System.out.println("-----------------------------------");
					System.out.println("Select Mass Unit:");
					System.out.println("   [1] Tons(t)");
					System.out.println("   [2] Ounces(oz)");
					System.out.println("   [3] Kilograms(kg)");
					System.out.println("   [4] Grams(g)");
					System.out.println("-----------------------------------");

					boolean c = true;
					while (c) {
						System.out.print("Convert to: ");
						int unit = s.nextInt();

						if (unit == 1) {
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (pounds * 0.000453592) + "t");
							System.out.println("===================================\n");
							c = false;
							t = false;
						} else if (unit == 2) {
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (pounds * 16) + "oz");
							System.out.println("===================================\n");
							c = false;
							t = false;
						} else if (unit == 3) {
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (pounds * 0.453592) + "kg");
							System.out.println("===================================\n");
							c = false;
							t = false;
						} else if (unit == 4) {
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (pounds * 453.592) + "g");
							System.out.println("===================================\n");
							c = false;
							t = false;
						} else {
							System.out.println("INVALID INPUT!");
						}
					}

					break;

				case 3:

					System.out.print("Input value of Ounces(oz): ");
					double ounces = s.nextDouble();

					System.out.println("-----------------------------------");
					System.out.println("Select Mass Unit:");
					System.out.println("   [1] Tons(t)");
					System.out.println("   [2] Pounds(lb)");
					System.out.println("   [3] Kilograms(kg)");
					System.out.println("   [4] Grams(g)");
					System.out.println("-----------------------------------");

					boolean f = true;
					while (f) {
						System.out.print("Convert to: ");
						int unit = s.nextInt();

						if (unit == 1) {
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (ounces * 0.0000283495) + "t");
							System.out.println("===================================\n");
							f = false;
							t = false;
						} else if (unit == 2) {
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (ounces * 0.0625) + "lb");
							System.out.println("===================================\n");
							f = false;
							t = false;
						} else if (unit == 3) {
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (ounces * 0.0283495) + "kg");
							System.out.println("===================================\n");
							f = false;
							t = false;
						} else if (unit == 4) {
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (ounces * 28.3495) + "g");
							System.out.println("===================================\n");
							f = false;
							t = false;
						} else {
							System.out.println("INVALID INPUT!");
						}
					}

					break;

				case 4:

					System.out.print("Input value of Kilograms(kg): ");
					double kilograms = s.nextDouble();

					System.out.println("-----------------------------------");
					System.out.println("Select Mass Unit:");
					System.out.println("   [1] Tons(t)");
					System.out.println("   [2] Pounds(lb)");
					System.out.println("   [3] Ounces(oz)");
					System.out.println("   [4] Grams(g)");
					System.out.println("-----------------------------------");

					boolean k = true;
					while (k) {
						System.out.print("Convert to: ");
						int unit = s.nextInt();

						if (unit == 1) {
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (kilograms * 0.001) + "t");
							System.out.println("===================================\n");
							k = false;
							t = false;
						} else if (unit == 2) {
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (kilograms * 2.20462) + "lb");
							System.out.println("===================================\n");
							k = false;
							t = false;
						} else if (unit == 3) {
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (kilograms * 35.274) + "oz");
							System.out.println("===================================\n");
							k = false;
							t = false;
						} else if (unit == 4) {
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (kilograms * 1000) + "g");
							System.out.println("===================================\n");
							k = false;
							t = false;
						} else {
							System.out.println("INVALID INPUT!");
						}
					}

					break;

				case 5:

					System.out.print("Input value of Grams(g): ");
					double grams = s.nextDouble();

					System.out.println("-----------------------------------");
					System.out.println("Select Mass Unit:");
					System.out.println("   [1] Tons(t)");
					System.out.println("   [2] Pounds(lb)");
					System.out.println("   [3] Ounces(oz)");
					System.out.println("   [4] Kilograms(kg)");
					System.out.println("-----------------------------------");

					boolean m = true;
					while (m) {
						System.out.print("Convert to: ");
						int unit = s.nextInt();

						if (unit == 1) {
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (grams * 0.000001) + "t");
							System.out.println("===================================\n");
							m = false;
							t = false;
						} else if (unit == 2) {
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (grams * 0.00220462) + "lb");
							System.out.println("===================================\n");
							m = false;
							t = false;
						} else if (unit == 3) {
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (grams * 0.035274) + "oz");
							System.out.println("===================================\n");
							m = false;
							t = false;
						} else if (unit == 4) {
							System.out.println("===================================");
							System.out.println("  ANSWER : " + (grams * 0.001) + "kg");
							System.out.println("===================================\n");
							m = false;
							t = false;
						} else {
							System.out.println("INVALID INPUT!");
						}
					}

					break;

				case 0:
					t = false;
					break;
				default:
					System.out.println("INVALID INPUT!");
					break;

			}
		}
		
	}
}
