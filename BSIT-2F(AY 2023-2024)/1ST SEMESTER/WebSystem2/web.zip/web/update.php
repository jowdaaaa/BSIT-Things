<?php

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        session_start();

        if ($_POST['password'] == "" || $_POST['password_confirm'] == "" || $_POST['password_current'] == "" || $_POST['name'] == "") {
            echo "All fields are required!";
        } else if ($_POST['password'] != $_POST['password_confirm']) {
            echo "Password and confirmed password did not match!";
        } else {
            
            $host = "127.0.0.1";
            $username = "root";
            $password = "";
            $dbname = "finals";

            // Create connection
            $conn = new mysqli($host, $username, $password, $dbname);
            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $_hashed_password = md5($_POST['password_current']);
            $_hashed_pass = md5($_POST['password']);
            
            $sql = "SELECT * FROM `user_status` WHERE `username` =  '".$_COOKIE['username']."' AND `password` = '".$_hashed_password."'";
            $result = $conn->query($sql);


            if ($result->num_rows > 0) {
                
                $sql = "UPDATE `user_status` SET `password` = '".$_hashed_pass."', `name` = '".$_POST['name']."' WHERE `username` = '".$_COOKIE['username']."'";
                $result = $conn->query($sql);
                setcookie('name', $_POST['name'], time() + (86400 * 30));
                echo '<meta http-equiv="refresh" content="3;url=http://127.0.0.1/web/welcome.php" />';
                echo "Account updated successfully!";
            } else {
                echo '<meta http-equiv="refresh" content="3;url=http://127.0.0.1/web/update.html" />';
                echo "Incorrect current password!";
            }

            $conn->close();

        }


    }