<?php
    session_start();

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {

        $host = "127.0.0.1";
        $username = "root";
        $password = "";
        $dbname = "finals";

        // Create connection
        $conn = new mysqli($host, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Validate user by checking username and password
        $_hashed_password = md5($_POST['password']);

        $sql = "SELECT * FROM user_status WHERE `username` = '".$_COOKIE['username']."' AND `password` = '".$_hashed_password."'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Update user status
            $newStatus = $_POST['newstatus'];
            $updateSql = "UPDATE user_status SET `status` = '".$newStatus."' WHERE `username` = '".$_COOKIE['username']."'";

            if ($conn->query($updateSql) === TRUE) {
                setcookie('status', $_POST['newstatus'], time() + (86400 * 30));
                echo '<meta http-equiv="refresh" content="3;url=http://127.0.0.1/web/welcome.php" />';
                echo "Status updated successfully!";
            } else {
                echo "Error updating status: " . $conn->error;
            }
        } else {
            echo "Invalid username or password.";
        }

        $conn->close();
    }
?>
